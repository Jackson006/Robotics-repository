# ISHP
For Lake Tuggeranong College 2021 S2 Robotics

This project will build a electronics board symbolising a traditional dwelling for a particular Australian Indigenous country, introducting Arduino and electronic technology.

Ryan Cather
